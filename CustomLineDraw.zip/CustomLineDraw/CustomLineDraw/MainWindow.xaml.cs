﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CustomLineDraw {

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {

        public MainWindow () {
            InitializeComponent ();

            DrawAxis ();
            DrawDots ();

            //FindMin ();
        }

        private void DrawDots () {
            Line e1;
            Line e2;
            TextBlock tb1;
            TextBlock tb2;

            for (int i = 50; i < 350; i += 20) {
                e1 = new Line ();
                e1.StrokeThickness = 10;
                e1.Stroke = Brushes.Red;
                e1.X1 = 100;
                e1.X2 = 100;
                e1.Y1 = i;
                e1.Y2 = i + 1;
                tb1 = new TextBlock ();
                tb1.Text = i.ToString ();
                tb1.Margin = new Thickness (100 + 5, e1.Y1 - 5, 0, -2);

                e2 = new Line ();
                e2.StrokeThickness = 10;
                e2.Stroke = Brushes.Red;
                e2.X1 = 400;
                e2.X2 = 400;
                e2.Y1 = i;
                e2.Y2 = i + 1;
                tb2 = new TextBlock ();
                tb2.Text = i.ToString ();
                tb2.Margin = new Thickness (400 + 5, e2.Y1 - 5, 0, 0);

                MainGrid.Children.Add (e1);
                MainGrid.Children.Add (tb1);
                MainGrid.Children.Add (e2);
                MainGrid.Children.Add (tb2);
            }
        }

        private void DrawAxis () {
            Line lineBase = new Line () { X1 = 100, Y1 = 350, X2 = 400, Y2 = 350 };
            lineBase.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineBase);

            Line lineA = new Line () { X1 = 100, Y1 = 50, X2 = 100, Y2 = 350 };
            lineA.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineA);

            Line lineB = new Line () { X1 = 400, Y1 = 50, X2 = 400, Y2 = 350 };
            lineB.Stroke = Brushes.Black;
            MainGrid.Children.Add (lineB);
        }

        private void Draw (object sender, RoutedEventArgs e) {
            Line l = new Line ();
            l.X1 = 100;
            l.Y1 = Convert.ToDouble (a.Text);
            l.X2 = 400;
            l.Y2 = Convert.ToDouble (b.Text);
            l.Stroke = Brushes.Purple;
            l.StrokeThickness = 0.5;

            MainGrid.Children.Add (l);
        }
    }
}